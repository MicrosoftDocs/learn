# simpleAspDotNetCoreWebapp
Simple ASP.NETCore Webapp for Learn modules.
