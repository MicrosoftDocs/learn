Choose the best response for each question. Then, select **Check your answers**.
